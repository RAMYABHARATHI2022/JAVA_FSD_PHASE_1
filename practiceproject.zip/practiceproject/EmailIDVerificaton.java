package practiceproject;

import java.util.ArrayList;
import java.util.Scanner;

public class EmailIDVerificaton {

	public static void main(String[] args) {
		ArrayList<String> emailID = new ArrayList<String>();
        
        emailID.add("gdfasyeghcv@gvyu.com");
        emailID.add("kanaka@jhgf.com");
        emailID.add("coffee@hfv.com");
        emailID.add("dfsefaz@ytf.com");
        emailID.add("utrtrcvhj@jye.com");
        emailID.add("serdfgchf@gsr.com");
        emailID.add("rsffsygerb@cfr.com");
        
      String searchEmail = null;
      System.out.println("Enter the E-mail to search");
         
      Scanner input = new Scanner(System.in);
      System.out.println("Enter E-mail Id : ");
      searchEmail = input.nextLine(); 
      if(emailID.contains(searchEmail))
      {
       	 System.out.println("E-mail ID" + " " + searchEmail + " " + "found");
      }
      else
      {
         System.out.println( "E-mail ID " +" "+ searchEmail +" "+ " not found");
      }
       input.close();
	}
}
