package assistedpracticeproject;

import java.io.*;

public class File 
{
	void Filewrite() throws FileNotFoundException,IOException 
	{
		DataInputStream dis=new DataInputStream(System.in);
		FileOutputStream Fout=new FileOutputStream("D://JAVA PROGRAM//JAVA FSD//src//Learning.txt",true);
		BufferedOutputStream Bout=new BufferedOutputStream(Fout,1024);
		
		System.out.println("Enter text (# at the end):"); 
		char ch; 
		while((ch=(char)dis.read())!='#') 
		{ 
			Bout.write(ch); 
		} 
		   	Bout.close();         //close the file 
	}
		  
	void Fileread() throws IOException 
	{
		          //attach the file to FileInputStream 
		FileInputStream Fin= new FileInputStream("D://JAVA PROGRAM//JAVA FSD//src//Learning.txt"); 
		int ch; 
		while((ch=Fin.read())!=-1) 
			System.out.print((char)ch); 
		Fin.close();       //close the file
	}

	public static void main(String[] args) 
	{
		File f= new File();
		try
		{
		f.Filewrite();
		f.Fileread();
		}
		catch(Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}
}