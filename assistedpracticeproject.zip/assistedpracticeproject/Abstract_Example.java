package assistedpracticeproject;

abstract class Vehicle
{
	Vehicle()
	{
		System.out.println("Vehicle is created");
	}
	abstract void run();
	abstract void stop();

	public void fuel(int a)
	{
		System.out.println("Enter the litre of fuel You want: "+a);
	}
	public void fuel(float b,String c)
	{
		System.out.println("How much cost of fuel? "+b+c);
	}
	public void fuel(char d,int e)
	{
		System.out.println("enter the char and int: "+d+e);
	}
	public void Default()
	{
		System.out.println(" ");
	}
	public void Parameterized(int f,int g)
	{
		System.out.println(" ");
	}
}
class Twowheeler extends Vehicle
{
	
}
public class Abstract_Example {

	public static void main(String[] args) {
		int speed;
		long distance;

	}

}
