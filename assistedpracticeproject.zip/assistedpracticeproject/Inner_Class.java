package assistedpracticeproject;

public class Inner_Class {
	private int a=20;
	class Inner
	{
		void msg()
		{
			System.out.println("Value of A: "+a);
		}
	}

	public static void main(String[] args) {
		Inner_Class obj=new Inner_Class();
		Inner_Class.Inner in=obj.new Inner();
		in.msg();
	}
}
