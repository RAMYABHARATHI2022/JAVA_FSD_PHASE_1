package assistedpracticeproject;

public class Shape {
	
	public int area(char r) {
		System.out.println("Area of circle:" + (3.14 * r * r));
		return 0;
	}

	public int area(int l, float b) {
		System.out.println("Area of rectangle:" + (l * b));
		return 0;
	}

	public int area(int a) {
		System.out.println("Area of sqare:" + (a * a));
		return 0;
	}

	public static void main(String[] args) {
		new Shape().area(2);
		new Shape().area(2, 3);
		new Shape().area('A');

	}

}
